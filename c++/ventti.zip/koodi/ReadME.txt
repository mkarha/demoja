Ventti Readme

Ventti on korttipeli, jossa on tarkoitus saada käden arvoksi mahdollisimman lähelle 21:tä.
Ässän arvo voi olla joko 1 tai 14.

Pelissä on käytössä yksi korttipakka.


PELIN KULKU

Pelin käynnistyessä peli tarjoaa mahdollisuuden joko aloittaa uusi peli (1) tai poistua
pelistä (0).
Pelin alussa selvitetään osallistujamäärä. 1-3 pelaajaa jakajan lisäksi ja kysytään
pelaajien nimet.

Kukin pelaaja nostaa vuorollaan kortteja ja pyrkii pääsemään korttien yhteenlasketulla arvolla
mahdollisimman lähelle 21:tä. Kortin maalla ei ole merkitystä.
Kunkin kortin jälkeen peli kysyy haluaako pelaaja jatkaa korttien nostamista (k/e), paitsi jos pelaajan
korttien yhteenlaskettu summa menee yli 21:n, jolloin vuoro päättyy. Peli jatkuu seuraavan pelaajan vuorolla
mitä tahansa näppäintä sekä enteriä painamalla.
Pelaajien jälkeen jakaja pyrkii saamaan yhtä hyvän tai paremman tuloksen kuin pelaajat.
Jakajalla on etu. Eli samalla tuloksella jakaja voittaa.
Pelin jälkeen ilmoitetaan kunkin pelaajan nostamien korttien summa sekä pelin lopputulos.

Pelin jälkeen palataan alkuvalikkoon, jossa voi valita haluaako pelata uuden pelin vai poistua.




